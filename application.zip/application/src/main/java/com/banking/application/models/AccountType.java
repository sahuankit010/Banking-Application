/**
 * @author Ankit Sahu
 **/

package com.banking.application.models;

public enum AccountType {

    CHECKING,
    SAVINGS;
}
