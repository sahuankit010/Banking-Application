/**
 * @author Ankit Sahu
 **/
package com.banking.application.models;
public enum TransactionType {

    DEPOSIT,
    WITHDRAW;
}
